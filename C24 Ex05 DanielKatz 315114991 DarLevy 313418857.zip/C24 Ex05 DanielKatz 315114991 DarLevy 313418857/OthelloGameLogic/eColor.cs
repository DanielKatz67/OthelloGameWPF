namespace OthelloGameLogic
{
    public enum eColor
    {
        White = 'o',
        Black = 'x',
    }
}

